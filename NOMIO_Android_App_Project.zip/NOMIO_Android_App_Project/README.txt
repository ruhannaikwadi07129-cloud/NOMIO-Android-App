NOMIO Android App — Starter Project (v0.1)

WHAT THIS IS
An Android Studio project that wraps the current NOMIO clickable prototype in a basic Android WebView app shell. It is a starting point for an installable Android app, not a production-ready food delivery service.

HOW TO BUILD AN APK
1. On a computer, install Android Studio from the official Android developer website.
2. Extract this ZIP.
3. In Android Studio, choose Open and select the extracted NOMIO_Android_App_Project folder.
4. Allow Gradle sync/downloads to finish.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the APK location when the build completes.
7. For testing, transfer the APK to your own Android phone and install it. Only install apps you built or trust.

LIMITATIONS / NEXT STEPS
- No server, account registration, OTP, actual restaurant onboarding, delivery-partner app, GPS tracking, real payments, refunds or order notifications.
- The address and phone fields in the prototype are demo-only; the app does not send them anywhere.
- Food imagery and the sample menu are illustrative.
- Before public launch, replace the demo order logic with a secure backend and validate the first-order-free-delivery promotion server-side.
- A trusted adult should help with business accounts, contracts, privacy compliance and payment-provider setup.
- This project has not been compiled or tested in Android Studio in this environment. Gradle/Android SDK downloads and a compatible JDK are required to build the APK.
